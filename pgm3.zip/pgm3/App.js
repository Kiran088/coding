import React, { Component } from 'react'
import example from './example'

class App extends Component {
  render() {
    return (
      <div><Example/></div>
    )
  }
}

export default App