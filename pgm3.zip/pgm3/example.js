import React, { Component } from 'react'

class Example extends Component {
    constructor(props){
        super(props);

        this.state={
            count:0
        }
    }

    Increment(){
       // this.state.count=this.state.count+1
       this.setState({
        count:this.state.count+1
       }),()=>{console.log("callback value",this.state.count)}
       console.log(this.state.count);
    }
    

  render() {
    return (
      <div><h1>example</h1>
        <div>count{this.state.count}</div>
        <button onClick={()=>this.Increment()}>Click</button>

      </div>
    )
  }
}

export default Example