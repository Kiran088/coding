package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registeration extends AppCompatActivity {
    private EditText e1,e2;
    private Button submit_button,back;
    private String user_name,pass;
    private static SQLiteHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        e1 = findViewById(R.id.PersonName2);
        e2 = findViewById(R.id.editTextTextPassword2);
        submit_button=findViewById(R.id.button3);
        back=findViewById(R.id.button4);
        helper=new SQLiteHelper(getBaseContext(),"userdb",null,1);


        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_name=e1.getText().toString();
                pass=e2.getText().toString();
                helper.insertData(user_name,pass);
                Toast.makeText(Registeration.this,"Success",Toast.LENGTH_SHORT).show();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Registeration.this,MainActivity.class);
                startActivity(intent);
            }
        });


    }
}