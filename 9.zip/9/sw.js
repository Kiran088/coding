self.addEventListener("install", (e) => {
    console.log("installed");
    caches.open("Hi")
        .then(s=>{
        return s.addAll(["index.html","manifest.json","assets/logo.png"])
        }
        )
})
    self.addEventListener("activate", (e) => {
    console.log("activated");
    })

    self.addEventListener("fetch", (e) => {
        console.log("fetched");
        // fetching user data from the github api
        fetch("https://api.github.com/users/Kiran088")
    .then((e) => {
        return e.json();
        })
        .then((json) => {
        console.log(json);
        })
        .catch((e) => {
        console.log(e);
        });
        })
        